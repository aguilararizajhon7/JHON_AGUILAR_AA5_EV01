from flask import Flask, render_template, request

app = Flask(__name__)

# Lista de usuarios
usuarios = []

# =========================
# PAGINA LOGIN
# =========================
@app.route('/')
def inicio():
    return render_template('login.html')

# =========================
# PAGINA REGISTRO
# =========================
@app.route('/registro', methods=['GET', 'POST'])
def registro():

    if request.method == 'POST':

        usuario = request.form['usuario']
        password = request.form['password']

        # Guardar usuario
        usuarios.append({
            'usuario': usuario,
            'password': password
        })

        return '''
        <h1 style="color:green;">
        Usuario registrado correctamente
        </h1>
        <a href="/">Ir al Login</a>
        '''

    return render_template('registro.html')

# =========================
# LOGIN
# =========================
@app.route('/login', methods=['POST'])
def login():

    usuario = request.form['usuario']
    password = request.form['password']

    for u in usuarios:

        if u['usuario'] == usuario and u['password'] == password:

            return '''
            <h1 style="color:lime;">
            Autenticación satisfactoria
            </h1>
            '''

    return '''
    <h1 style="color:red;">
    Error en la autenticación
    </h1>
    '''

# =========================
# EJECUTAR SERVIDOR
# =========================
if __name__ == '__main__':
    app.run(debug=True)